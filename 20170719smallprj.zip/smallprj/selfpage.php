<?php
    session_start();
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <style>
            .container .row .col-sm-3 {
                
                height :350px;
                width : 350px;
                background-color : lightblue;
                margin :20px;
            }
            
            .container .row .col-sm-12 {
                
                height :350px;
                width : 1130px;
                background-color : lightblue;
                margin :20px;
            }
            
            .copyright{
                height : 100px;
            }
            .Name{
            position : absolute;
            right :30px;
            bottom : 20px;
            color : black;
        }
            
            .boxBtn{
                position : absolute;
                bottom: 10px;
                left: 35%;
                
            }
            #navbar{
                background-color: 	#66FF66;
            }
            #jumbotron_index{
                height:400px;
                /*background-image:url("image/jumbotron.jpg");*/
                background-repeat:no-repeat;
                background-size:100%,contain;
                opacity: 0.8;
            }
            #jumbotron_text{
                font-family: 標楷體;
                color : black;
                line-height:100px;
            }
            #box_joinus{
                /*background-image:url("image/joinus.jpg");*/
                background-repeat:no-repeat;
                background-size: 350px 350px;
                opacity: 0.8;
            }
            #box_boardlist{
                /*background-image:url("image/board.jpg");*/
                background-repeat:no-repeat;
                background-size: 350px 400px;
                opacity: 0.8;
            }
            #box_lend{
                /*background-image:url("image/lend.jpg");*/
                background-repeat:no-repeat;
                background-size: 350px 350px;
                opacity: 0.8;
            }
            #space{
                
                background-size: 350px 350px;
                background-color: white;
            }
        </style>
    </head>
    <body>
        <!--導覽列-->
        <nav id = "navbar" class="navbar navbar-default">
          <div class="container-fluid">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div  class="navbar-header">
                  <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                  </button>
              <a class="navbar-brand" href="#">Brand</a>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
              <ul class="nav navbar-nav">
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Dropdown <span class="caret"></span></a>
                    <ul class="dropdown-menu">
                        <li><a href="#">Action</a></li>
                        <li><a href="#">Another action</a></li>
                        <li><a href="#">Something else here</a></li>
                        <li role="separator" class="divider"></li>
                        <li><a href="#">Separated link</a></li>
                        <li role="separator" class="divider"></li>
                        <li><a href="#">One more separated link</a></li>
                     </ul>
                </li>
              </ul>
                <!--<form class="navbar-form navbar-left">-->
                <!--    <div class="form-group">-->
                <!--        <input type="text" class="form-control" placeholder="Search">-->
                <!--    </div>-->
                <!--    <button type="submit" class="btn btn-default">Submit</button>-->
                <!--</form>-->
                <ul class="nav navbar-nav navbar-right">
                <li><a href="login.php">登入</a></li>
                <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Dropdown <span class="caret"></span></a>
                  <ul class="dropdown-menu">
                    <li><a href="#">Action</a></li>
                    <li><a href="#">Another action</a></li>
                    <li><a href="#">Something else here</a></li>
                    <li role="separator" class="divider"></li>
                    <li><a href="#">Separated link</a></li>
                  </ul>
                </li>
            </ul>
            </div><!-- /.navbar-collapse -->
          </div><!-- /.container-fluid -->
        </nav>
        
        
        
        <!--面板分割-->
        <div class="container" >
            <div class="row">
                <div class="col-sm-3" id="box_waitlist" >
                    <p class="boxBtn"><a class="btn btn-primary btn-lg"  role="button" href="self_court.php">最愛球場</a></p>
                </div>
                <div class="col-sm-3" id="box_waitlist" >
                    <p class="boxBtn"><a class="btn btn-primary btn-lg"  role="button" href="self_court.php">推薦球場</a></p>
                </div>
                
            </div>
            
        </div>
        
    
    <!--footer-->
    <div>   
        <div class="row">
            <div class = "col-sm-12" style = "background-color:#00FF99 ;min-height :70px" >
                <div class="Information">
                    <ul>
                        <li><a href="https://www.google.com.tw/maps">聯絡地址:台中市</a></li>
                        <li>聯絡電話 : 0912345678 </li>
                    </ul>
                </div>
                <div class = "Name">
                        @ design by Ben  
                </div>
                
            </div>
        </div>
    <div>    
        <script src="js/jquery.js"></script>
        <script src="js/bootstrap.min.js"></script>
    </body>
</html>