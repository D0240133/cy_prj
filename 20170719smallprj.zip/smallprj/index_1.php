<?php
    session_start();
    
    
    
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <style>
            .container .row .col-sm-3 {
                
                height :350px;
                width : 350px;
                background-color : lightblue;
                margin :20px;
            }
            .copyright{
                height : 100px;
            }
            .Name{
                position : absolute;
                right :30px;
                bottom : 20px;
                color : black;
            }
            
            .boxBtn{
                position : absolute;
                bottom: 10px;
                left: 35%;
                
            }
            #navbar{
                background-color: 	#66FF66;
            }
            #jumbotron_index{
                height:400px;
                background-image:url("image/jumbotron.jpg");
                background-repeat:no-repeat;
                background-size:100%,contain;
                opacity: 0.8;
            }
            #jumbotron_text{
                font-family: 標楷體;
                color : black;
                line-height:100px;
            }
            #box_joinus{
                background-image:url("image/joinus.jpg");
                background-repeat:no-repeat;
                background-size: 350px 350px;
                opacity: 0.8;
            }
            #box_boardlist{
                background-image:url("image/board.jpg");
                background-repeat:no-repeat;
                background-size: 350px 400px;
                opacity: 0.8;
            }
            #box_lend{
                background-image:url("image/lend.jpg");
                background-repeat:no-repeat;
                background-size: 350px 350px;
                opacity: 0.8;
            }
        </style>
    </head>
    <body>
        <!--導覽列-->
        <nav id = "navbar" class="navbar navbar-default">
          <div class="container-fluid">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div  class="navbar-header">
                  <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                  </button>
              <a class="navbar-brand" href="index_1.php">Brand</a>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
              
                <!--<form class="navbar-form navbar-left">-->
                <!--    <div class="form-group">-->
                <!--        <input type="text" class="form-control" placeholder="Search">-->
                <!--    </div>-->
                <!--    <button type="submit" class="btn btn-default">Submit</button>-->
                <!--</form>-->
                <ul class="nav navbar-nav navbar-right">
                    <li><a href="login.php">登入</a></li>
                </ul>
            </div><!-- /.navbar-collapse -->
          </div><!-- /.container-fluid -->
        </nav>
        
        <!--大圖區-->
        <div class="jumbotron" id="jumbotron_index">
	        <div class="container">
	          <h1 id ="jumbotron_text">籃球場地交流網</h1>
	        </div>
        </div> 
        
        <!--面板分割-->
        <div class="container" >
        <div class="row">
            <div class="col-sm-3" id="box_boardlist" >
                <p class="boxBtn"><a class="btn btn-primary btn-lg"  role="button" href="courtlist.php">場地總覽</a></p>
            </div>
            <!--<div class="col-sm-3" id="box_lend">-->
            <!--    <p class="boxBtn"><a class="btn btn-primary btn-lg"  role="button">場地借用</a></p>-->
            <!--</div>-->
            <div class="col-sm-3" id="box_joinus">
                <p class="boxBtn"><a class="btn btn-primary btn-lg"  role="button"  href="login.php">會員系統</a></p>
            </div>
            
        </div>
    </div>
    
        <!--footer-->
        <div>   
            <div class="row">
                <div class = "col-sm-12" style = "background-color:#00FF99 ;min-height :70px" >
                    <div class="Information">
                        <ul>
                            <li><a href="https://www.google.com.tw/maps">聯絡地址:台中市</a></li>
                            <li>聯絡電話 : 0912345678 </li>
                        </ul>
                    </div>
                    <div class = "Name">
                            @ design by Ben  
                    </div>
                    
                </div>
            </div>
        </div>    
        <script src="js/jquery.js"></script>
        <script src="js/bootstrap.min.js"></script>
    </body>
</html>