<?php
  //前置處理
  session_start();
  require("connectMysql.php");
  $result = mysqli_select_db($db_link,"project");
?>
<?php
  //資料庫處理
  function checkCourt($name){
    global $db_link;
    $check_flag = true;
    $str = "select * from `court` where cname="."'$name'";
    $result = mysqli_query($db_link,$str);
    //有重複
    if($result->num_rows>0){
      $check_flag = false;
    }
    return $check_flag;
  }
  function insertCourt(){
    global $db_link;
    $str = "insert into `court` (`cname`,`caddress`,`ctype`,`cpay`,`csex`) 
                        values ('".$_POST['cname']."','".$_POST['caddress']."','".$_POST['ctype']."','".$_POST['cpay']."','".$_POST['csex']."')";
    $result = mysqli_query($db_link,$str);
    
  }
  
?>
<?php
  //表單處理
  $_SESSION["cname"]=$_POST["cname"];
  $_SESSION["caddress"]=$_POST["caddress"];
  $_SESSION["ctype"]=$_POST["ctype"];
  $_SESSION["cpay"]=$_POST["cpay"];
  $_SESSION["csex"]=$_POST["csex"];
  if(isset($_POST["btnOK"])){
    //先判斷是否輸入完成
    if(($_POST["cname"]!=null)&&$_POST["caddress"]!=null){
        //判斷是否重複輸入
        if(checkCourt($_POST["cname"])){
           insertCourt();
        }
        else {
          echo "該球場已存在，請重新輸入<br>";
        }
    }
    else{
        echo "球場名稱及地址不可空白<br>";
    }
  }
  if(isset($_POST["btnCancel"])){
        header("location:index_1.php");
  }
  
  
?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <link href="css/style_ok.css" rel="stylesheet">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <title>球場資訊</title>
    </head>
    <body>
        <div class="container login" >
          <div class="col-md-offset-4 col-md-4">   
              <div class="form-group has-error">
                      <label><h2>新增球場</h2></label>
              </div>
              <form role="form" method="post" action="" >
                  <div class="form-group has-error">
                      <label>球場名稱</label>
                      <input type="text" class="form-control" id="cname" name="cname" placeholder="請輸入球場名稱">
                  </div>
                  <div class="form-group has-warning">
                      <label for="exampleInputPassword1 inputWarning">地址</label>
                      <input type="text" class="form-control" id="caddress" name="caddress" placeholder="請輸入球場地址" >
                  </div>
                  
                  <div class="form-group has-warning">
                      <label for="exampleInputPassword1 inputWarning">種類</label>
                      <select class="form-control" name="ctype" id="ctype">
                        <option>室外</option>
                        <option>室內</option>
                        <option>風雨球場</option>
                      </select>
                  </div>
                  <div class="form-group has-warning">
                      <label for="exampleInputPassword1 inputWarning">租金</label>
                      <select class="form-control" name="cpay" id="cpay">
                        <option>有</option>
                        <option>無</option>
                      </select>
                  </div>
                  <div class="form-group has-warning">
                      <label for="exampleInputPassword1 inputWarning">優先使用</label>
                      <select class="form-control" name="csex" id="csex">
                        <option>一般</option>
                        <option>女生優先</option>
                        
                      </select>
                  </div>
                  <!--<div class="form-group has-error">-->
                  <!--    <label>球場照片</label>-->
                  <!--    <input type="file" class="form-control" id="cPhoto" name="cPhoto">-->
                  <!--</div>-->
                  <button type="submit" name="btnOK" class="btn btn-default btn-primary">送出</button>
                  <button type="submit" name="btnCancel" class="btn btn-default btn-primary">取消</button>
              </form>
              <div class="form-group has-error">
                      <label><?php echo $errmsg; ?></label>
              </div>
          </div>
      </div>
        
        
        <script src="js/jquery.js"></script>
        <script src="js/bootstrap.min.js"></script>
    </body>
</html>