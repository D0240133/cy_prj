<?php   
    require("connectMysql.php");
    mysqli_select_db($db_link,"project");
?>
<?php
    if(isset($_GET["uID"])){
        if($_GET["uID"]!=""){
            $tempID  = $_GET["uID"];
            $str = "select * from `members` where uID="."'$tempID'";
            $result = mysqli_query($db_link,$str);
            
            if($result->num_rows ==0){
                $msg = "這個帳號可以使用<br>";
            }
            else{
                $msg = "這個帳號已經被使用，請重新輸入<br>";
            }
        }
        else{
            $msg = "請輸入帳號<br>";
        }
    }
    
    if(isset($_GET["email"])){
        if($_GET["email"]!=""){
            $tempEmail  = $_GET["email"];
            $str = "select * from `members` where Email="."'$tempEmail'";
            $result = mysqli_query($db_link,$str);
            
            if($result->num_rows ==0){
                $msg = "這個信箱可以使用<br>";
            }
            else{
                $msg = "這個信箱已經被使用，請重新輸入<br>";
            }
        }
        else{
            $msg = "請輸入信箱<br>";
        }
    }
    
    if(isset($_GET["upassword"])&&isset($_GET["upasswordCheck"])){
        if($_GET["upassword"]!=$_GET["upasswordCheck"]){
            $msg = "密碼驗證錯誤!<br>";
        }
        else {
             $msg = "ok<br>";
        }
    }

    echo $msg;
?>