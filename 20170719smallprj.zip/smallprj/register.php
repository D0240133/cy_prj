<?php
    //前置處理
    session_start();
    require("connectMysql.php");
    $result = mysqli_select_db($db_link,"project");
?>
<?php
    //資料庫處理
   
    function checkForm($uID,$email){
        global $db_link;
        $checkFlag = true;
        $str = "select * from `members` where uID="."'$uID'";
        //echo $str ;
        $result = mysqli_query($db_link,$str);
        
        // echo "$uID<br>";
        // echo $result->num_rows;
        
        //有找到重複的
        if ($result->num_rows > 0){
            $checkFlag = false;
        }
        $str = "select * from `members` where Email="."'$email'";
        $result = mysqli_query($db_link,$str);
        //echo "$email<br>";
        //echo var_dump($result);
        if ($result->num_rows > 0){
            $checkFlag = false;
        }
            //$str = "INSERT INTO `dbtest`.`temp` (`nickname`, `time`) VALUES ('".$_POST['player']."', '$date');";
        //echo "$checkFlag";
        return $checkFlag;
    }
    function insertMember(){
        global $db_link;
        //將資料寫入資料庫
        $str = "insert into `members` (`uID`,`upassword`,`sex`,`nickname`,`Email`) 
                                   values ('".$_POST['uID']."', '".$_POST['upassword']."','".$_POST['sex']."','".$_POST['nickname']."','".$_POST['email']."')";
        $result = mysqli_query($db_link,$str);
        
    }
?>
<?php
    //表單處理
    $_SESSION["nickname"]=$_POST["nickname"];
    $_SESSION["uID"] = $_POST["uID"];
    $_SESSION["upassword"] = $_POST["upassword"];
    $_SESSION["email"] = $_POST["email"];
    $_SESSION["sex"] = $_POST["sex"];
    if(isset($_POST["btnOK"])){
        //先判斷是否輸入完成
        //echo $_POST["nickname"];
        if(($_POST["nickname"]!=null) && ($_POST["uID"]!=null) &&
           ($_POST["upassword"]!=null)&& ($_POST["upassword"]==$_POST["upasswordCheck"])&&
           ($_POST["email"]!=null)    &&($_POST["sex"]!=null)){
            //輸入完成，先判斷是否有重複的帳號及Email 正確:true
            if(checkForm($_POST["uID"],$_POST["email"])){
                echo "success";
                insertMember();
            }
            else{
                echo "帳號或Email已經被使用過，請重新輸入<br>";
            }
        }
        else{
            echo "error!";
        }
    }
    if(isset($_POST["btnCancel"])){
        header("location:index_1.php");
    }
   
?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>註冊</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <script type='text/javascript' src='ajax_register.js'></script>
        <script type="text/javascript" src="jquery.js"></script>
        <style>
            .login{
                position:absolute;
                left:5%;
            }
            
        </style>
        <script >
            $(document).ready(function(){
                $("#uID").on(
                    "blur",
                    function(){
                        checkID();
                    }
                );
                 $("#email").on(
                    "blur",
                    function(){
                        checkEmail();
                    }
                );
                $("#upasswordCheck").on(
                    "blur",
                    function(){
                        checkpassword();
                    }
                );
            })
            
        </script>
        
    </head>
    <body>
         <div class="container login" >
          <div class="col-md-offset-4 col-md-4">   
              <div class="form-group has-error">
                      <label><h2>註冊</h2></label>
              </div>
              <form role="form" method="post" action="">
                  <div class="form-group has-error">
                      <label>暱稱</label>
                      <input type="text" class="form-control" id= "nickname" name="nickname" placeholder="請輸入暱稱" value = <?php echo $_SESSION['nickname']?>>
                  </div>
                  <?php if($_SESSION['sex'] = "male") { ?>                  
                  <div class="form-group has-error">
                      <label>性別</label>
                      <label class="radio-inline">
                          <input type="radio" name="sex" id="sex_m" value="male" checked="true"/>
                          男
                      </label>
                      <label class="radio-inline">
                          <input type="radio" name="sex" id="sex_f" value="female"/>
                          女
                      </label>
                  </div>
                  <?php }else if ($_SESSION['sex'] = "female"){ ?>
                  <div class="form-group has-error">
                      <label>性別</label>
                      <label class="radio-inline">
                          <input type="radio" name="sex" id="sex_m" value="male" />
                          男
                      </label>
                      <label class="radio-inline">
                          <input type="radio" name="sex" id="sex_f" value="female" checked="true"/>
                          女
                      </label>
                  </div>
                  <?php }else{?>
                  <div class="form-group has-error">
                      <label>性別</label>
                      <label class="radio-inline">
                          <input type="radio" name="sex" id="sex_m" value="male"/>
                          男
                      </label>
                      <label class="radio-inline">
                          <input type="radio" name="sex" id="sex_f" value="female"/>
                          女
                      </label>
                  </div>
                  <?php }?>
                  <div class="form-group has-error">
                      <label>帳號</label>
                      <input type="text" class="form-control" id="uID" name="uID" placeholder="請輸入帳號" value=<?php echo $_SESSION['uID']; ?>>
                      <div id="ResponseDiv_uID">Hello?</div>
                  </div>
                  <div class="form-group has-warning">
                      <label for="exampleInputPassword1 inputWarning">密碼</label>
                      <input type="password" class="form-control" id="upassword" name="upassword" placeholder="請輸入密碼" >
                  </div>
                  <div class="form-group has-warning">
                      <label for="exampleInputPassword1 inputWarning">確認密碼</label>
                      <input type="password" class="form-control" id="upasswordCheck" name="upasswordCheck" placeholder="請再輸入密碼">
                      <div id="ResponseDiv_upasswordCheck">Hello?</div>
                  </div>
                  
                  <div class="form-group has-warning">
                      <label for="exampleInputPassword1 inputWarning">信箱</label>
                      <input type="email" class="form-control" id="email" name="email" placeholder="abcd@xxxx.com" value=<?php echo $_SESSION['email']; ?>>
                      <div id="ResponseDiv_email">Hello?</div>
                  </div>
                  <!--<div class="form-group has-warning">-->
                  <!--    <label for="exampleInputPassword1 inputWarning">身分</label>-->
                  <!--    <select class="form-control">-->
                  <!--      <option>一般</option>-->
                  <!--      <option>商家</option>-->
                  <!--    </select>-->
                  <!--</div>-->
                  <button type="submit" name="btnOK" class="btn btn-default btn-primary">送出</button>
                  <button type="submit" name="btnCancel" class="btn btn-default btn-primary">取消</button>
              </form>
              <div class="form-group has-error">
                      <label><?php echo $errmsg; ?></label>
              </div>
          </div>
      </div>
        
        
        <script src="js/jquery.js"></script>
        <script src="js/bootstrap.min.js"></script>
    </body>
</html>