<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Play One</title>
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <style>
            .login{
                position:absolute;
                top:25%;
                left:10%;
            }
            .btnRight{
                position : absolute;
                right : 10px;
            }
        </style>
    </head>
    <body>
        <div class="container login" >
    <div class="col-md-offset-4 col-md-4">   <!--將畫面設為在版面的中間-->
        <div class="form-group has-error">
                <label>Play one</label>
        </div>
        <form role="form" method="post">
            <div class="form-group has-error">
                <label>隊名</label>
                <input type="text" class="form-control" name="teamname" placeholder="請輸入隊名">
            </div>
           
            <button type="submit" name="btnEnter" class="btn btn-default btn-primary">報隊</button>
            <button type="submit" name="btnCancel" class="btn btn-default btn-primary">取消</button>
            
        </form>
        <div class="form-group has-error">
                <label></label>
        </div>
    </div>
</div>
        
        
        
        <script src="js/jquery.js"></script>
        <script src="js/bootstrap.min.js"></script>
    </body>
</html>