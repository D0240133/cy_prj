<?php
    session_start();
    
    echo "登入成功!即將為你轉至其他頁面";
?>