<?php
    //前置處理
     session_start();
     require("connectMysql.php");
?>
<?php
    //資料庫處理
    $result =  mysqli_select_db($db_link,"project");
    function checkLogin($uID,$upassword){
        global $db_link;
        $checkFlag = 0;
        $str = "select * from `members` where uID="."'$uID'";
        $result = mysqli_query($db_link,$str);
        //如果沒有這個帳號
        if($result->num_rows == 0){
            echo "no such ID<br>";
            $checkFlag=1;
        }
        else{
            echo "Find ID<br>";
            //判斷密碼和帳號是否相符
            $row = mysqli_fetch_assoc($result);
            if($row["upassword"]!=$upassword){
                $checkFlag =2;
            }
        }
        return $checkFlag;
    }
?>
<?php
    //當按下登入時
    if(isset($_POST["btnLogin"])){
        //判斷是否有輸入帳號
        if($_POST["uID"]!=""&&$_POST["upassword"]!=""){
            echo "1";
            $_SESSION = $_POST["uID"];
            $checkFlag = checkLogin($_POST["uID"],$_POST["upassword"]);
            switch ($checkFlag) {
                case 0:
                    echo "登入成功<br>";
                    break;
                case 1:
                    echo "沒有這個帳號<br>";
                    break;
                case 2:
                    echo "密碼錯誤<br>";
                    break;
                default:
                    
                    break;
            }
            
            //header("Location:test.php");
        }
        //沒有輸入帳號
        else{
            echo "2  ".$_POST["uID"];
            $errmsg="請輸入正確的帳號及密碼!";
        }
    }
    if(isset($_POST["btnCancel"])){
        header("Location:index_1.php");
    }
    if(isset($_POST["btnRegister"])){
        $_SESSION["lastpage"]="login.php";
        header("Location:register.php");
    }
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>登入</title>
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <style>
            .login{
                position:absolute;
                top:25%;
                left:10%;
            }
            .btnRight{
                position : absolute;
                right : 10px;
            }
        </style>
    </head>
    <body>
        <div class="container login" >
    <div class="col-md-offset-4 col-md-4">   <!--將畫面設為在版面的中間-->
        <div class="form-group has-error">
                <label>登入</label>
        </div>
        <form role="form" method="post">
            <div class="form-group has-error">
                <label>帳號</label>
                <input type="text" class="form-control" name="uID" placeholder="請輸入帳號">
            </div>
            <div class="form-group has-warning">
                <label for="exampleInputPassword1 inputWarning">密碼</label>
                <input type="password" class="form-control" name="upassword" placeholder="請輸入密碼">
            </div>
            <button type="submit" name="btnLogin" class="btn btn-default btn-primary">登入</button>
            <button type="submit" name="btnCancel" class="btn btn-default btn-primary">取消</button>
            <button type="submit" name="btnRegister" class="btn btn-default btn-primary btnRight">註冊</button>
        </form>
        <div class="form-group has-error">
                <label><?php echo $errmsg; ?></label>
        </div>
    </div>
</div>
        
        
        
        <script src="js/jquery.js"></script>
        <script src="js/bootstrap.min.js"></script>
    </body>
</html>