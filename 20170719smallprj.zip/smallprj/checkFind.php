<?php
    $str = "Ben";
    
    if(isset($_GET["uID"])){
        if($_GET["uID"]!=$str){
            $msg = "不存在這個帳號";
        }
        else{
            $msg ="這個帳號可以使用";
        }
    }
    sleep(2);
    echo $msg;
?>