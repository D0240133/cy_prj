<?php
    session_start();
    if(isset($_POST["submit"])){
        $_SESSION["username"] = $_POST["username"];
        header("Location:login.php");
    }
    
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="css/bootstrap.min.css" rel="stylesheet">
    </head>
    <body>
        
        <form method="post" action"login.php">
            <input type="text" name="username"/>
            <input type="submit" name = "submit" value="Submit"/>
        </form>
        
        <script src="js/jquery.js"></script>
        <script src="js/bootstrap.min.js"></script>
    </body>
</html>