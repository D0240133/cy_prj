<?php
    //前置處理
    session_start();
    require("connectMysql.php");
    $result = mysqli_select_db($db_link,"project");
?>
<?php
    //資料庫處理
    $cNo = $_GET['cNo'];
    $str = "select * from `court` where `cNo`="."'$cNo'";
    $result = mysqli_query($db_link,$str);
    $row = mysqli_fetch_assoc($result);
?>
<?php
    //其他function(抓取球場位置應對的經緯度)
    $address = $row['caddress'];
    $url = "https://maps.googleapis.com/maps/api/geocode/json?address=$address=AIzaSyCNrMk4fK4FrnDlaU1AXjMeoBsuLYXYKgg";
    $file = fopen($url,"r");
    $content = "";
    while(!feof($file)) {
        $content .= fgets($file,100);
    }
    fclose($file); 
    $findstr1 = "\"lat\" : ";
    $findstr2 = "\"lng\" : ";
    //echo $content;
    $index_start = strpos($content,$findstr1);
    
    $lat = substr($content,$index_start+strlen($findstr1),9);
    //echo $lat."<br>";
    $index_start = strpos($content,$findstr2);
    
    $ltn = substr($content,$index_start+strlen($findstr2),9);
    //echo $lat;

?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
       
        <link href="css/style_ok.css" rel="stylesheet">
        <meta name="viewport" content="initial-scale=1.0">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <title>球場資訊</title>
        <script src="/js/Bootstrap/Select/bootstrap-select.js"></script>
        <script>
            function initMap() {
                var uluru = {lat: <?php echo $lat ?>, lng: <?php echo $ltn ?>};
                var map = new google.maps.Map(document.getElementById('box_map'), {
                    zoom: 16,
                    center: uluru
                });
                var marker = new google.maps.Marker({
                    position: uluru,
                    map: map
                });
             }
             
             
             
        </script>
        <!--google map API KEY-->
        <script async defer
            src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCNrMk4fK4FrnDlaU1AXjMeoBsuLYXYKgg&callback=initMap">
        </script>
        
        
        <style >
            .container .row .col-sm-3 {
                
                height :350px;
                width : 350px;
                background-color : lightblue;
                margin :20px;
            }
            .boxBtn{
                position : absolute;
                bottom: 10px;
                left: 35%;
                
            }
             .Name{
                position : absolute;
                right :30px;
                bottom : 20px;
                color : black;
            }
            
            #jumbotron_index{
                height:400px;
                background-image:url("image/jumbotron.jpg");
                background-repeat:no-repeat;
                background-size:100%,contain;
                opacity: 0.8;
            }
            #jumbotron_text{
                font-family: 標楷體;
                color : black;
                line-height:100px;
            }
           
            select{
                width:200px;
            }
             #box_map {
                height: 350px;
                width: 350px;
              }
               #box_playone {
                background-size: 350px 350px;
                height: 350px;
                width: 350px;
              }
            
        </style>
    </head>
    <body>
        <!--導覽列-->
        <nav class="navbar navbar-default">
          <div class="container-fluid">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                  <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                  </button>
              <a class="navbar-brand" href="#">Brand</a>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
              <ul class="nav navbar-nav">
                <li class="active"><a href="#">Link <span class="sr-only">(current)</span></a></li>
                <li><a href="#">Link</a></li>
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Dropdown <span class="caret"></span></a>
                    <ul class="dropdown-menu">
                        <li><a href="#">Action</a></li>
                        <li><a href="#">Another action</a></li>
                        <li><a href="#">Something else here</a></li>
                        <li role="separator" class="divider"></li>
                        <li><a href="#">Separated link</a></li>
                        <li role="separator" class="divider"></li>
                        <li><a href="#">One more separated link</a></li>
                     </ul>
                </li>
              </ul>
                <form class="navbar-form navbar-left">
                    <div class="form-group">
                        <input type="text" class="form-control" placeholder="Search">
                    </div>
                    <button type="submit" class="btn btn-default">Submit</button>
                </form>
                <ul class="nav navbar-nav navbar-right">
                <li><a href="#">登入</a></li>
                <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Dropdown <span class="caret"></span></a>
                  <ul class="dropdown-menu">
                    <li><a href="#">Action</a></li>
                    <li><a href="#">Another action</a></li>
                    <li><a href="#">Something else here</a></li>
                    <li role="separator" class="divider"></li>
                    <li><a href="#">Separated link</a></li>
                  </ul>
                </li>
            </ul>
            </div><!-- /.navbar-collapse -->
          </div><!-- /.container-fluid -->
        </nav>
       
        <div class="container">
            
            
            
            
        </div>
        <!--詳細資料-->
        <div class="container">
            <div class="bs-callout bs-callout-info">
                <h4>球場名稱:<?php echo $row['cname'] ?></h4>
            </div>
            <div class="bs-callout bs-callout-info">
                <p>地址 : <?php echo $row['caddress'] ?></p>
            </div>
            <div class="bs-callout bs-callout-info">
                <p>種類 : <?php echo $row['ctype'] ?> </p>
            </div>
            <div class="bs-callout bs-callout-info">
                <p>租金 : <?php echo $row['cpay'] ?></p>
            </div>
            <div class="bs-callout bs-callout-info">
                <p>優先使用 : <?php echo $row['csex'] ?></p>
            </div>
        </div>
        
      
         
        <!--面板分割-->
        <div class="container" >
            <div class="row">
                
                <div class="col-sm-3"  id="box_map">
                   
                 
                </div>
                <div class="col-sm-3" id="box_playone">
                    <p class="boxBtn"><a class="btn btn-primary btn-lg"  role="button" href="playone.php">我要報隊</a></p>
                </div>
                <div class="col-sm-3" id="box_likethis">
                    <p class="boxBtn"><a class="btn btn-primary btn-lg" id= role="button">我要收藏</a></p>
                </div>
            </div>
        </div>
        
        <!--footer-->
        <div>   
            <div class="row">
                <div class = "col-sm-12" style = "background-color:#00FF99 ;min-height :70px" >
                    <div class="Information">
                        <ul>
                            <li><a href="https://www.google.com.tw/maps">聯絡地址:台中市</a></li>
                            <li>聯絡電話 : 0912345678 </li>
                        </ul>
                    </div>
                    <div class = "Name">
                            @ design by Ben  
                    </div>
                    
                </div>
            </div>
        <div>    
       
        
        <script src="js/jquery.js"></script>
        <script src="js/bootstrap.min.js"></script>
    </body>
</html>