function getXMLHttp(){
  var xmlHttp

  try
  {
    //Firefox, Opera 8.0+, Safari
    xmlHttp = new XMLHttpRequest();
  }
  catch(e)
  {
    //Internet Explorer
    try
    {
      xmlHttp = new ActiveXObject("Msxml2.XMLHTTP");
    }
    catch(e)
    {
      try
      {
        xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
      }
      catch(e)
      {
        alert("Your browser does not support AJAX!")
        return false;
      }
    }
  }
  return xmlHttp;
}

function HandleResponse(response,callby)
{
  ID = 'ResponseDiv_'+ callby;
  document.getElementById(ID).innerHTML = response;
 
}  

function  checkID(){
  var xmlHttp = getXMLHttp();
  
  xmlHttp.onreadystatechange = function(){
     if(xmlHttp.readyState==4){
       HandleResponse(xmlHttp.responseText,"uID");
     }
  }
  
  tempID = document.getElementById('uID').value;
  
  xmlHttp.open("GET","ajaxserver_register.php?uID="+ tempID,true);
  xmlHttp.send(null);
    
}

function  checkpassword(){
  var xmlHttp = getXMLHttp();
  
  xmlHttp.onreadystatechange = function(){
    if(xmlHttp.readyState==4){
      HandleResponse(xmlHttp.responseText,"upasswordCheck");
    }
  }
  temppassword = document.getElementById('upassword').value;
  temppasswordcheck = document.getElementById('upasswordCheck').value;
  
  xmlHttp.open("GET","ajaxserver_register.php?upasswordCheck="+temppasswordcheck+"&upassword="+temppassword ,true);
  xmlHttp.send(null);
    
}

function  checkEmail(){
  var xmlHttp = getXMLHttp();
  
  xmlHttp.onreadystatechange = function(){
     if(xmlHttp.readyState==4){
       HandleResponse(xmlHttp.responseText,"email");
     }
  }
  
  tempEmail = document.getElementById('email').value;
  
  xmlHttp.open("GET","ajaxserver_register.php?email="+ tempEmail,true);
  xmlHttp.send(null);
    
}




