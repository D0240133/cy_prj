<?php
    session_start();
    session_unset();
    echo "Success!";
    
    
?>

<!DOCTYPE html>
<html>
    <head>
        
    </head>
    <body>
        
    </body>
</html>